package com.example.myapplicationfrutas;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner fruitsSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fruitsSpinner = findViewById(R.id.fruitsSpinner);

        // Crear una lista de frutas
        List<String> fruitsList = new ArrayList<>();
        fruitsList.add("Manzana");
        fruitsList.add("Sandia");
        fruitsList.add("Naranja");
        fruitsList.add("Uva");
        fruitsList.add("Piña");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, fruitsList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner fruitsSpinner = findViewById(R.id.fruitsSpinner);
        fruitsSpinner.setAdapter(adapter);

        fruitsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedFruit = fruitsList.get(position);
                Toast.makeText(getApplicationContext(), "Has seleccionado: " + selectedFruit, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Método requerido pero no se utiliza en este caso
            }

        });}}